public class Jester_The_Tester {
    public static void main(String[] args) {
        UI test= new UI();
        test.start();
    }
}
